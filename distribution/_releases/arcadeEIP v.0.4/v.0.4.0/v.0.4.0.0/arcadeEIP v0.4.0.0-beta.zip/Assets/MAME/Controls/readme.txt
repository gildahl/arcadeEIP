This folder is for control panel map images
(typically displayed on pause).

Place game specific images in the \Rom subfolder.
Place a system specific image in the \System subfolder.