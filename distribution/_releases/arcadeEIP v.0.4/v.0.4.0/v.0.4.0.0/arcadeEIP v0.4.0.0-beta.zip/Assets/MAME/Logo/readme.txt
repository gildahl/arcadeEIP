This folder is for clear logo images

Place game specific images in the \Rom subfolder.
Place a system specific image in the \System subfolder.