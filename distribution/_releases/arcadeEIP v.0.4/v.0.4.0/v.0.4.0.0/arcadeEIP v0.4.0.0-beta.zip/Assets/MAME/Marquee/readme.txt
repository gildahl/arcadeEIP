This folder is for marquee images
(typically displayed on a separate marquee monitor)

Place game specific images in the \Rom subfolder.
Place a system specific image in the \System subfolder.